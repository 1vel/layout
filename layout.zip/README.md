# Basic Flex Layout
### Objective
Building a really simple yet powerfull responsive template or layout for web design using flex.
- Current progress: 5%
### This layout
You can see it on:
- https://main.layouts.tk
### Some structure and layout samples 
These are some of my other "structure layouts", just mere samples of how to build up your website structure:
- https://layouts.tk
